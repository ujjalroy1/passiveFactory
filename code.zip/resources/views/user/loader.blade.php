<div id="loader">
    <img src="{{ asset('fine-app/assets/img/loading-icon.png') }}" alt="icon" class="loading-icon">
</div>
<?php echo e($slot); ?>

<?php /**PATH /home/sourav/Tilok/passiveFactory/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>
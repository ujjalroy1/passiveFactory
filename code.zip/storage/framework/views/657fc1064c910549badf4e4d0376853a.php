    <!-- ========= JS Files =========  -->
    <!-- Bootstrap -->
    <script src="<?php echo e(asset('fine-app/assets/js/lib/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Ionicons -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <!-- Splide -->
    <script src="<?php echo e(asset('fine-app/assets/js/plugins/splide/splide.min.js')); ?>"></script>
    <!-- Base Js File -->
    <script src="<?php echo e(asset('fine-app/assets/js/base.js')); ?>"></script>

    <script>
        // Add to Home with 2 seconds delay.
        AddtoHome("2000", "once");
    </script><?php /**PATH /home/sourav/Tilok/passiveFactory/resources/views/user/jsfile.blade.php ENDPATH**/ ?>
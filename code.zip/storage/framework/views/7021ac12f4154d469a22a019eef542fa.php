<div id="loader">
    <img src="<?php echo e(asset('fine-app/assets/img/loading-icon.png')); ?>" alt="icon" class="loading-icon">
</div><?php /**PATH /home/sourav/Tilok/passiveFactory/resources/views/user/loader.blade.php ENDPATH**/ ?>
<div class="appHeader bg-primary text-light">
    <div class="left">
        <a href="#" class="headerButton" data-bs-toggle="modal" data-bs-target="#sidebarPanel">
            <ion-icon name="menu-outline"></ion-icon>
        </a>
    </div>
    <div class="pageTitle">
        <img src="<?php echo e(asset('fine-app/assets/img/logo1.jpg')); ?>" alt="logo" class="logo">
    </div>
    <div class="right">

        <?php if(Route::has('login')): ?>
        <?php if(auth()->guard()->check()): ?>
        <div class="container">
            <label>Your User ID</label>
            <div class="input-group">
                <!-- Display the dynamic account ID from the controller -->
                <input type="text" id="userId" value="<?php echo e($account_id); ?>" disabled>
                <button onclick="copyToClipboard()">Copy</button>
            </div>
            <div class="message" id="copyMessage" style="display: none">ID Copied to Clipboard!</div>
        </div>
        <?php endif; ?>
            
        <?php endif; ?>

        
        <a href="#" class="headerButton">
            <ion-icon class="icon" name="notifications-outline"></ion-icon>
            <span class="badge badge-danger">4</span>
        </a>
        <a href="<?php echo e(asset('user_profile')); ?>" class="headerButton">
            <img src="<?php echo e(asset('fine-app/assets/img/sample/avatar/avatar1.jpg')); ?>" alt="image" class="imaged w32">
            
        </a>
    </div>
</div>


<script>
    function copyToClipboard() {
        // Get the value of the disabled input field
        var userIdValue = document.getElementById("userId").value;

        // Create a temporary input field to copy the value
        var tempInput = document.createElement("input");
        tempInput.style.position = "absolute";
        tempInput.style.left = "-9999px"; // Position it off-screen
        tempInput.value = userIdValue;

        // Append the input to the body, select its value, and copy it
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand("copy");

        // Remove the temporary input field
        document.body.removeChild(tempInput);

        // Show the "Copied" message
        var copyMessage = document.getElementById("copyMessage");
        copyMessage.style.display = "block";

        // Hide the message after 2 seconds
        setTimeout(function() {
            copyMessage.style.display = "none";
        }, 2000);
    }
</script>
<?php /**PATH /home/sourav/Tilok/passiveFactory/resources/views/user/app_header.blade.php ENDPATH**/ ?>
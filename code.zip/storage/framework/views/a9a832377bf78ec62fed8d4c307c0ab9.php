<div id="cookiesbox" class="offcanvas offcanvas-bottom cookies-box" tabindex="-1" data-bs-scroll="true"
data-bs-backdrop="false">
<div class="offcanvas-header">
    <h5 class="offcanvas-title">We use cookies</h5>
</div>
<div class="offcanvas-body">
    <div>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla non lacinia quam. Nulla facilisi.
        <a href="#" class="text-secondary"><u>Learn more</u></a>
    </div>
    <div class="buttons">
        <a href="#" class="btn btn-primary btn-block" data-bs-dismiss="offcanvas">I understand</a>
    </div>
</div>
</div><?php /**PATH /home/sourav/Tilok/passiveFactory/resources/views/user/cookie.blade.php ENDPATH**/ ?>
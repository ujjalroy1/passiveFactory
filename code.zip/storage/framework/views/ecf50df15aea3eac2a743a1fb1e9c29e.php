<!doctype html>
<html lang="en">

<head>
       <?php echo $__env->make('user.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <!-- loader -->
        <?php echo $__env->make('user.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * loader -->

    <!-- App Header -->
         <?php echo $__env->make('user.app_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * App Header -->


    <!-- App Capsule -->
 
    <div id="appCapsule">
        <style>
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }
    
            caption {
                caption-side: top;
                font-size: 1.5em;
                font-weight: bold;
                margin-bottom: 10px;
                text-align: center;
            }
    
            th, td {
                border: 1px solid #ddd;
                padding: 8px;
                text-align: center;
            }
    
            th {
                background-color: #4CAF50; /* Dark background for header */
                color: white; /* Light text color for header */
            }
    
            tr:nth-child(even) {
                background-color: #f2f2f2; /* Alternating row color */
            }
    
            td {
                background-color: #ffffff; /* Light background for rows */
                color: #333333; /* Dark text color */
            }
    
            table, th, td {
                border: 1px solid #ccc; /* Border for the whole table */
            }
    
            tr:hover {
                background-color: #ddd; /* Hover effect */
            }
        </style>

        <table>
            <caption>Your Current Package</caption>
            <tr>
                <th>Your Package Name</th>
                <th>Price</th>
                <th>Duration</th>
                <th>Started At</th>
            </tr>
            <!-- Simulating dynamic data from Laravel Blade template -->
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($d->type); ?></td>
                <td><?php echo e($d->price); ?></td>
                <td><?php echo e($d->duration); ?></td>
                <td><?php echo e($d->created_at); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
       


    </div>
                

    <!-- * App Capsule -->

    
    <!-- App Bottom Menu -->
        <?php echo $__env->make('user.app_bottom_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * App Bottom Menu -->

    <!-- App Sidebar -->
    <?php echo $__env->make('user.app_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <!-- * App Sidebar -->



    <!-- iOS Add to Home Action Sheet -->
      <?php echo $__env->make('user.ios', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * iOS Add to Home Action Sheet -->


    <!-- Android Add to Home Action Sheet -->
   <?php echo $__env->make('user.android', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * Android Add to Home Action Sheet -->

    <?php echo $__env->make('user.cookie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   
    <?php echo $__env->make('user.jsfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>

</html><?php /**PATH /home/sourav/Tilok/passiveFactory/resources/views/user/show_bought_package.blade.php ENDPATH**/ ?>
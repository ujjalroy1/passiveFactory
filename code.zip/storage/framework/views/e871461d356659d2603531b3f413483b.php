<!doctype html>
<html lang="en">

<head>
       <?php echo $__env->make('user.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <!-- loader -->
        <?php echo $__env->make('user.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * loader -->

    <!-- App Header -->
         <?php echo $__env->make('user.app_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * App Header -->


    <!-- App Capsule -->

            
    <div class="text-center p-6 max-w-lg bg-white rounded-lg shadow-lg">
        <h1 class="text-6xl mb-4">😕</h1>
        <h2 class="text-3xl font-bold text-gray-800 mb-2">Page Not Working</h2>
        <p class="text-gray-600 mb-6">This page is currently not working. Please try again later.</p>
     
      </div>

    <!-- * App Capsule -->

     
    <!-- App Bottom Menu -->
        <?php echo $__env->make('user.app_bottom_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * App Bottom Menu -->

    <!-- App Sidebar -->
    <?php echo $__env->make('user.app_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <!-- * App Sidebar -->



    <!-- iOS Add to Home Action Sheet -->
      <?php echo $__env->make('user.ios', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * iOS Add to Home Action Sheet -->


    <!-- Android Add to Home Action Sheet -->
   <?php echo $__env->make('user.android', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * Android Add to Home Action Sheet -->

    <?php echo $__env->make('user.cookie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   
    <?php echo $__env->make('user.jsfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>

</html><?php /**PATH /home/sourav/Tilok/passiveFactory/resources/views/user/error_handel_page.blade.php ENDPATH**/ ?>
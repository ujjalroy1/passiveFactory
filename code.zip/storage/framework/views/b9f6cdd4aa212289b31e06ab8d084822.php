<!doctype html>
<html lang="en">

<head>
       <?php echo $__env->make('user.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <!-- loader -->
        <?php echo $__env->make('user.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * loader -->

    <!-- App Header -->
         <?php echo $__env->make('user.app_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * App Header -->


    <!-- App Capsule -->
 
    <div id="appCapsule">


        <style type="text/css">
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}


#container-ujjal {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
    width: 100%;
}

#team-box-ujjal {
    width: 320px;
    background-color: #fff;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
    text-align: center;
}

#header-ujjal {
    background: linear-gradient(45deg, #6ac1a5, #458764);
    padding: 15px;
    color: white;
    font-size: 18px;
    font-weight: bold;
}

.level-title-ujjal {
    background-color: #e0e0e0;
    padding: 10px;
    font-weight: bold;
    color: #333;
    margin-bottom: 10px;
}

.member-row-ujjal {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 15px;
}

.member-name-ujjal {
    font-size: 16px;
    font-weight: 500;
}

.details-btn-ujjal {
    padding: 5px 10px;
    background-color: #38b673;
    border: none;
    border-radius: 5px;
    color: white;
    cursor: pointer;
}

.details-btn-ujjal:hover {
    background-color: #2f9e5c;
}

#level1-ujjal .member-row-ujjal {
    background-color: #c7e8d5;
}

#level2-ujjal .member-row-ujjal {
    background-color: #f3b8b8;
}

#level3-ujjal .member-row-ujjal {
    background-color: #f3b8b8;
}

.see-more-ujjal {
    padding: 10px;
    color: #0073e6;
    cursor: pointer;
}

#referral-section-ujjal {
    display: flex;
    justify-content: space-between;
    padding: 10px;
    background-color: #ffd580;
}

#referral-link-ujjal {
    width: 75%;
    padding: 5px;
    border: none;
    background-color: #fff;
    font-size: 14px;
}

#copy-btn-ujjal {
    padding: 5px 10px;
    background-color: #ff7b54;
    border: none;
    color: white;
    cursor: pointer;
    border-radius: 5px;
}

#copy-btn-ujjal:hover {
    background-color: #ff6a3c;
}

        </style>


<div id="container-ujjal">
    <div id="team-box-ujjal">
        <div id="header-ujjal">My Team</div>

        <div id="level1-ujjal">
            <div class="level-title-ujjal">Level 1</div>
            <?php
                $i=0;
            ?>
            <?php $__currentLoopData = $level1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lv1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
               <?php
               $i++;
                  if($i>3)
                  {
                     break;
                  }
               ?>
            <form action="<?php echo e(url('myTeamDetails',$lv1)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="member-row-ujjal">
                    <span class="member-name-ujjal"><?php echo e($lv1); ?></span>
                    
                    <input type="submit" value="Details" class="details-btn-ujjal">
                </div>
                
            </form>

                                         
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <div class="see-more-ujjal">

                   <a href="<?php echo e(url('myTeamInfo',1)); ?>">
                    See More
                   </a>

            </div>
        </div>

        <div id="level2-ujjal">
            <div class="level-title-ujjal">Level 2</div>
            <?php $__currentLoopData = $level2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lv2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <form action="<?php echo e(url('myTeamDetails',$lv2)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="member-row-ujjal">
                    <span class="member-name-ujjal"><?php echo e($lv2); ?></span>
                    <input type="submit" value="Details" class="details-btn-ujjal">
                </div>

            </form>

                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <div class="see-more-ujjal">

                <a href="<?php echo e(url('myTeamInfo',2)); ?>">
                    See More
                   </a>


            </div>
        </div>

        <div id="level3-ujjal">
            <div class="level-title-ujjal">Level 3</div>
            <?php $__currentLoopData = $level3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lv3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

             <form action="<?php echo e(url('myTeamDetails',$lv3)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="member-row-ujjal">
                    <span class="member-name-ujjal"><?php echo e($lv3); ?></span>
                    <input type="submit" value="Details" class="details-btn-ujjal">
                </div>

             </form>

                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="see-more-ujjal">
                <a href="<?php echo e(url('myTeamInfo',3)); ?>">
                    See More
                   </a>

            </div>

        </div>

        <div id="referral-section-ujjal">
            <input type="text" id="referral-link-ujjal" value="<?php echo e($account_id); ?>" readonly />
            <button id="copy-btn-ujjal">Copy</button>
        </div>
    </div>
</div>
       <script>
          document.getElementById('copy-btn-ujjal').addEventListener('click', function() {
    const referralLink = document.getElementById('referral-link-ujjal');
    referralLink.select();
    referralLink.setSelectionRange(0, 99999); // For mobile devices
    navigator.clipboard.writeText(referralLink.value);

    alert('Referral ID copied: ' + referralLink.value);
});

       </script>


    </div>
                

    <!-- * App Capsule -->

    
    <!-- App Bottom Menu -->
        <?php echo $__env->make('user.app_bottom_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * App Bottom Menu -->

    <!-- App Sidebar -->
    <?php echo $__env->make('user.app_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <!-- * App Sidebar -->



    <!-- iOS Add to Home Action Sheet -->
      <?php echo $__env->make('user.ios', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * iOS Add to Home Action Sheet -->


    <!-- Android Add to Home Action Sheet -->
   <?php echo $__env->make('user.android', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * Android Add to Home Action Sheet -->

    <?php echo $__env->make('user.cookie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   
    <?php echo $__env->make('user.jsfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>

</html><?php /**PATH /home/sourav/Tilok/passiveFactory/resources/views/user/my_team.blade.php ENDPATH**/ ?>
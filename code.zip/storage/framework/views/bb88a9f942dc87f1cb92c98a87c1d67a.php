<div class="appBottomMenu">
    <a href="<?php echo e(url('home')); ?>" class="item <?php echo e(request()->is('home') ? 'active' : ''); ?>">
        <div class="col">
            <ion-icon name="home-outline"></ion-icon>
            <strong>Home</strong>
        </div>
    </a>
    <a href="<?php echo e(url('captcha1')); ?>" class="item <?php echo e(request()->is('captcha1') ? 'active' : ''); ?>">
        <div class="col">
            <ion-icon name="people-outline"></ion-icon>
            <strong>Task</strong>
        </div>
    </a>
    <a href="<?php echo e(url('package')); ?>" class="item <?php echo e(request()->is('package') ? 'active' : ''); ?>">
        <div class="col">
            <ion-icon name="cart-outline"></ion-icon>
            <strong>Buy Package</strong>
        </div>
    </a>
    <a href="<?php echo e(url('myTeam')); ?>" class="item <?php echo e(request()->is('myTeam') ? 'active' : ''); ?>">
        <div class="col">
            <ion-icon name="apps-outline"></ion-icon>
            <strong>Team</strong>
        </div>
    </a>
    <a href="#" class="item">
        <div class="col">
            <ion-icon name="card-outline"></ion-icon>
            <strong>Collectable</strong>
        </div>
    </a>
    <a href="<?php echo e(asset('show/boughtPackage')); ?>" class="item <?php echo e(request()->is('boughtPackage') ? 'active' : ''); ?>">
        <div class="col">
            <ion-icon name="person-outline"></ion-icon>
            <strong>profile</strong>
        </div>
    </a>
</div><?php /**PATH /home/sourav/Tilok/passiveFactory/resources/views/user/app_bottom_menu.blade.php ENDPATH**/ ?>
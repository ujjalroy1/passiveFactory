<!doctype html>
<html lang="en">

<head>
       <?php echo $__env->make('user.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <!-- loader -->
        <?php echo $__env->make('user.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * loader -->

    <!-- App Header -->
         <?php echo $__env->make('user.app_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * App Header -->


    <!-- App Capsule -->
    <div id="appCapsule">
        <style type="text/css">
            * {
                box-sizing: border-box;
            }
        
            .container {
                max-width: 1200px;
                margin: auto;
            }
        
            .cards {
                display: flex;
                justify-content: space-between;
                flex-wrap: wrap;
                margin-bottom: 20px;
            }
        
            .card {
                background-color: #fff;
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 20px;
                margin: 10px;
                flex: 1 1 23%; /* Responsive: 4 cards in a row */
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                transition: transform 0.2s;
                cursor: pointer;
            }
        
            .card:hover {
                transform: translateY(-5px);
            }
        
            .card h3 {
                margin: 0 0 10px;
            }
        
            .card p {
                color: #555;
            }
        
            .buy-button {
                background-color: #ddd; /* Inactive color */
                color: white;
                border: none;
                padding: 7px 10px;
                border-radius: 5px;
                cursor: not-allowed; /* Inactive state */
            }
        
            .buy-button.active {
                background-color: #007bff; /* Active color */
                cursor: pointer;
            }
        
            .buy-button:hover.active {
                background-color: #0056b3;
            }
        
            .info-area {
                margin-top: 20px;
                
            }
        
            textarea {
                width: 100%;
                height: 100px;
                border: 1px solid #ddd;
                border-radius: 5px;
                padding: 10px;
                font-size: 16px;
                resize: none;
                background-color: #f9f9f9;
                color: #333;
            }
        </style>
        
        <div class="container">
            <div class="info-area">
                <textarea id="infoTextArea" readonly placeholder="Click on a card to see its info here..."></textarea>
            </div>
        
            <?php $__currentLoopData = $package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="cards">
                <div class="card" data-info="<?php echo e($pk->benifit); ?>">
                    <h3><?php echo e($pk->name); ?></h3>
                    <p>Price: <?php echo e($pk->price); ?>$</p>
                    <label>Fill the box to activate buy</label><input type="checkbox" class="buy-checkbox">
                    
                    <form action="<?php echo e(url('buyPackage',$pk->id)); ?>" method="POST" class="buy-form">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="name" value="<?php echo e($pk->name); ?>">
                        <input type="hidden" name="price" value="<?php echo e($pk->price); ?>">
                        <textarea name="benifit" readonly style="display: none;"><?php echo e($pk->benifit); ?></textarea>
                        <input type="submit" class="buy-button" value="Buy Now" disabled>
                    </form>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <script>
            // Add click event listeners to each card
            document.querySelectorAll('.card').forEach(card => {
                card.addEventListener('click', function() {
                    // Get the information from the data attribute
                    const info = card.getAttribute('data-info');
                    
                    // Set the textarea's value to the card's info
                    document.getElementById('infoTextArea').value = info;
                });
            });
        
            // Handle checkbox change events to enable/disable the buy button
            document.querySelectorAll('.buy-checkbox').forEach((checkbox, index) => {
                checkbox.addEventListener('change', function() {
                    const form = document.querySelectorAll('.buy-form')[index];
                    const buyButton = form.querySelector('.buy-button');
                    
                    if (checkbox.checked) {
                        buyButton.disabled = false;
                        buyButton.classList.add('active');
                    } else {
                        buyButton.disabled = true;
                        buyButton.classList.remove('active');
                    }
                });
            });
        </script>
        
    </div>
    <!-- * App Capsule -->

     
    <!-- App Bottom Menu -->
        <?php echo $__env->make('user.app_bottom_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * App Bottom Menu -->

    <!-- App Sidebar -->
    <?php echo $__env->make('user.app_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <!-- * App Sidebar -->



    <!-- iOS Add to Home Action Sheet -->
      <?php echo $__env->make('user.ios', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * iOS Add to Home Action Sheet -->


    <!-- Android Add to Home Action Sheet -->
   <?php echo $__env->make('user.android', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- * Android Add to Home Action Sheet -->

    <?php echo $__env->make('user.cookie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   
    <?php echo $__env->make('user.jsfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>

</html><?php /**PATH /home/sourav/Tilok/passiveFactory/resources/views/user/package.blade.php ENDPATH**/ ?>